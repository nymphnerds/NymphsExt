# Hunyuan 3D is licensed under the TENCENT HUNYUAN NON-COMMERCIAL LICENSE AGREEMENT
# except for the third-party components listed below.
# Hunyuan 3D does not impose any additional limitations beyond what is outlined
# in the repsective licenses of these third-party components.
# Users must comply with all terms and conditions of original licenses of these third-party
# components and must ensure that the usage of the third party components adheres to
# all relevant laws and regulations.

# For avoidance of doubts, Hunyuan 3D means the large language models and
# their software and algorithms, including trained model weights, parameters (including
# optimizer states), machine-learning model code, inference-enabling code, training-enabling code,
# fine-tuning enabling code and other elements of the foregoing made publicly available
# by Tencent in accordance with TENCENT HUNYUAN COMMUNITY LICENSE AGREEMENT.

bl_info = {
    "name": "Nymphs3D2",
    "author": "Nymphs3D",
    "version": (1, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > Nymphs3D",
    "description": "Blender-first Nymphs3D workflow with lightweight server status",
    "category": "3D View",
}
import base64
import json
import logging
import os
import re
import subprocess
import tempfile
import threading
import time
from urllib.parse import urlparse

import bpy
import requests
from bpy.props import StringProperty, BoolProperty, IntProperty, FloatProperty, EnumProperty


logging.getLogger("urllib3").setLevel(logging.WARNING)
logging.getLogger("requests").setLevel(logging.WARNING)


DEFAULT_CONFIG = {
    "hunyuan2_path": "~/Hunyuan3D-2",
    "hunyuan21_path": "~/Hunyuan3D-2.1",
    "port": "8080",
}
CONFIG_PATH = os.path.join(os.path.expanduser("~"), ".hunyuan_launcher_config.json")
PRESET_PATH = os.path.join(os.path.expanduser("~"), ".nymphs3d2_blender_presets.json")
GPU_REFRESH_SECONDS = 2.0
SERVER_REFRESH_DEBOUNCE_SECONDS = 2.0
ACTIVE_TASK_IDLE_SECONDS = 8.0
ACTIVE_TASK_BUSY_SECONDS = 1.5
ACTIVE_TASK_UNAVAILABLE_SECONDS = 15.0
ACTIVE_TASK_DIRECT_JOB_SECONDS = 0.75
SERVER_SYNC_SECONDS = 2.0
SERVER_INFO_READY_SECONDS = 6.0
SERVER_INFO_LAUNCHING_SECONDS = 2.0
SERVER_INFO_UNAVAILABLE_SECONDS = 10.0
SERVER_LAUNCH_GRACE_SECONDS = 45.0
STAGE_RE = re.compile(r"STAGE:\s*([A-Za-z0-9_]+)")
PROGRESS_RE = re.compile(r"PROGRESS:\s*([A-Za-z0-9_ -]+)\s+(\d+)/(\d+)")
_last_gpu_poll = 0.0
_last_server_refresh_request = 0.0
_server_refresh_inflight = False
_active_task_refresh_inflight = False
_server_process = None
_server_process_lock = threading.Lock()
_gpu_cache = {
    "name": "Unknown",
    "memory": "Unavailable",
    "utilization": "Unavailable",
    "status": "Not checked",
}
_server_cache = {
    "status": "Not checked",
    "model_path": "Unknown",
    "subfolder": "Unknown",
    "enable_flashvdm": "Unknown",
    "enable_tex": "Unknown",
    "enable_t23d": "Unknown",
}
_active_task_cache = {
    "status": "idle",
    "stage": "",
    "detail": "",
    "progress_text": "",
    "message": "",
}
_launcher_config = None


def _http_request(method, url, *, json_payload=None, timeout=None):
    _ensure_network_access(url)
    kwargs = {}
    if json_payload is not None:
        kwargs["json"] = json_payload
    if timeout is not None:
        kwargs["timeout"] = timeout
    return requests.request(method, url, **kwargs)


def _stage_label(stage):
    labels = {
        "startup": "Starting server",
        "request_received": "Request Received",
        "loading_input_image": "Loading Input",
        "loading_shape_pipeline": "Loading Shape",
        "sampling_shape": "Generating Shape",
        "shape_ready": "Shape Ready",
        "loading_texture_pipeline": "Loading Texture",
        "generating_texture": "Generating Texture",
        "texture": "Generating Texture",
        "texture_ready": "Texture Ready",
        "exporting_mesh": "Exporting Mesh",
        "exporting_textured_mesh": "Exporting Textured Mesh",
        "failed": "Failed",
    }
    if not stage:
        return ""
    return labels.get(stage, stage.replace("_", " ").title())


def _tag_ui_redraw():
    wm = getattr(bpy.context, "window_manager", None)
    if wm is None:
        return
    for window in wm.windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


def _format_progress_text(current=None, total=None, percent=None):
    if current is not None and total:
        return f"{current}/{total}"
    if percent is not None:
        try:
            return f"{float(percent):.0f}%"
        except Exception:
            return str(percent)
    return ""


def _infer_backend(model_path, subfolder):
    joined = f"{model_path} {subfolder}".lower()
    if "2.1" in joined:
        return "2.1"
    if "2mv" in joined or "mv" in joined:
        return "2mv"
    if "hunyuan3d-2" in joined:
        return "2.0"
    return "Unknown"


def _clean_output_line(line):
    return (line or "").replace("\r", "").strip()


def _filtered_output_message(line):
    text = _clean_output_line(line)
    if not text:
        return None, None, None

    stage_match = STAGE_RE.search(text)
    if stage_match:
        label = _stage_label(stage_match.group(1))
        return label, "", ""

    progress_match = PROGRESS_RE.search(text)
    if progress_match:
        label = _stage_label(progress_match.group(1).strip().replace(" ", "_").lower())
        return label, "", f"{progress_match.group(2)}/{progress_match.group(3)}"

    if "Diffusion Sampling" in text:
        match = re.search(r"(\d+)/(\d+)", text)
        return "Diffusion Sampling", "", f"{match.group(1)}/{match.group(2)}" if match else ""

    if "Volume Decoding" in text:
        match = re.search(r"(\d+)/(\d+)", text)
        return "Volume Decoding", "", f"{match.group(1)}/{match.group(2)}" if match else ""

    if "Loading the model" in text:
        return "Loading shape model", "", ""
    if "Loading texture" in text or "loading_texture_pipeline" in text:
        return "Loading texture pipeline", "", ""
    if "Loading text bridge" in text or "loading_text_bridge" in text:
        return "Loading text bridge", "", ""
    if "Application startup complete." in text or "Uvicorn running on http://" in text:
        return "Server ready", "", ""
    if text.startswith("[server ready]"):
        return "Server ready", "", ""

    return None, None, None


def _apply_startup_progress(stage="", detail="", progress=""):
    for scene in bpy.data.scenes:
        props = getattr(scene, "nymphs3d2_props", None)
        if props is None:
            continue
        props.startup_stage = stage
        props.startup_detail = detail
        props.startup_progress = progress
    _tag_ui_redraw()
    return None


def _queue_startup_progress(stage="", detail="", progress=""):
    bpy.app.timers.register(
        lambda: _apply_startup_progress(stage=stage, detail=detail, progress=progress),
        first_interval=0.0,
    )


def _progress_lines(props):
    if props.server_control_state == "Launching":
        return (
            props.startup_stage or "",
            props.startup_detail or props.server_control_message or "",
            props.startup_progress or "",
        )
    if not props.is_processing:
        return "", "", ""
    if props.waiting_for_backend_progress:
        return (
            "Request Sent",
            "Waiting for backend progress...",
            "",
        )
    active_status = (props.active_task_status or "").lower()
    if active_status not in {"processing", "queued"}:
        return (
            "Request Sent",
            "Waiting for backend progress...",
            "",
        )
    stage = (props.active_task_stage or "").strip()
    detail = (props.active_task_detail or props.active_task_message or "").strip()
    progress = (props.active_task_progress or "").strip()
    if _is_hidden_stage(stage):
        return (
            "Request Sent",
            "Waiting for backend progress...",
            "",
        )
    return (
        stage or "Working",
        detail,
        progress,
    )


def _server_panel_job_lines(props):
    if props.server_control_state == "Launching":
        stage = props.startup_stage or ""
        detail = props.startup_detail or props.server_control_message or ""
        progress = props.startup_progress or ""
        return stage, detail, progress
    if not props.is_processing:
        return "", "", ""
    if props.waiting_for_backend_progress:
        return "Request Sent", "Waiting for backend progress...", ""
    return _progress_lines(props)


def _normalized_panel_text(text):
    return " ".join((text or "").strip().lower().split())


def _is_boot_only_stage(stage):
    normalized = (stage or "").strip().lower()
    return normalized in {
        "server boot complete",
        "server ready",
        "starting server",
        "launch requested",
    }


def _is_hidden_stage(stage):
    normalized = (stage or "").strip().lower()
    return normalized in {
        "",
        "completed",
        "job complete",
        "server boot complete",
        "server ready",
        "starting server",
        "launch requested",
    }


def _server_status_line(props):
    backend = _infer_backend(props.server_model_path, props.server_subfolder)
    backend_label = backend if backend != "Unknown" else props.server_backend
    server_available = props.server_status not in {"Unavailable", "Not checked", ""}
    state = (props.server_control_state or "").strip()
    launch_grace_active = (
        props.server_launch_requested_at > 0
        and (time.time() - props.server_launch_requested_at) < SERVER_LAUNCH_GRACE_SECONDS
    )
    if server_available and state not in {"Launching", "Stopping"}:
        return f"{backend_label} Ready"
    if state == "Launching" or (launch_grace_active and not server_available):
        return f"{backend_label} Launching"
    if state == "Stopping":
        return "Stopping"
    if server_available:
        return f"{backend_label} {props.server_status}"
    return "Server stopped"


def _current_vram_estimate(props):
    backend = props.server_backend
    texture = bool(props.server_start_texture)
    flashvdm = bool(props.server_flashvdm)
    turbo = bool(props.server_turbo)
    low_vram = bool(props.server_low_vram)
    if props.prompt.strip():
        input_mode = "text_prompt"
    elif props.use_multiview:
        input_mode = "multiview"
    else:
        input_mode = "single_image"

    if backend == "2.1":
        if texture:
            estimate = "29 GB total"
            basis = "Basis: official"
            mode = "Shape + texture"
            if low_vram:
                caveat = "Low VRAM may help fit; no exact official replacement figure."
            else:
                caveat = "Low VRAM is recommended on 16 GB GPUs."
            return estimate, basis, mode, caveat
        if input_mode == "text_prompt":
            estimate = "10-12 GB"
            basis = "Basis: official + inferred"
            mode = "Shape + text bridge"
            if low_vram:
                caveat = "Low VRAM may help fit; bridge overhead is not separately published."
            else:
                caveat = "10 GB shape is official; bridge overhead is inferred."
            return estimate, basis, mode, caveat
        estimate = "10 GB"
        basis = "Basis: official"
        mode = "Shape only"
        if low_vram:
            caveat = "Low VRAM may reduce pressure, but no exact official number is published."
        else:
            caveat = "Official 2.1 shape figure."
        return estimate, basis, mode, caveat

    if texture:
        estimate = "16-24.5 GB total"
        basis = "Basis: official range"
        mode = "Shape + texture"
        if turbo or flashvdm:
            caveat = "README says 16 GB; modelzoo says 24.5 GB. Turbo/FlashVDM have no separate official VRAM figure."
        else:
            caveat = "README says 16 GB; modelzoo says 24.5 GB."
        return estimate, basis, mode, caveat
    if input_mode == "text_prompt":
        estimate = "8-10 GB"
        basis = "Basis: official + inferred"
        mode = "Shape + text bridge"
        if turbo or flashvdm:
            caveat = "6 GB shape is official; bridge overhead is inferred. Turbo/FlashVDM have no separate official VRAM figure."
        else:
            caveat = "6 GB shape is official; bridge overhead is inferred."
        return estimate, basis, mode, caveat
    if input_mode == "multiview":
        estimate = "6-8 GB"
        basis = "Basis: official + inferred"
        mode = "2mv shape"
        if turbo or flashvdm:
            caveat = "6 GB shape is official; multiview overhead is inferred. Turbo/FlashVDM are speed features."
        else:
            caveat = "6 GB shape is official; exact 2mv-only VRAM is not separately published."
        return estimate, basis, mode, caveat
    estimate = "6-8 GB"
    basis = "Basis: official + inferred"
    mode = "Shape only"
    if turbo or flashvdm:
        caveat = "6 GB shape is official; extra headroom is conservative. Turbo/FlashVDM have no separate official VRAM figure."
    else:
        caveat = "6 GB shape is official; extra headroom is conservative."
    return estimate, basis, mode, caveat


def _load_launcher_config():
    global _launcher_config
    if _launcher_config is not None:
        return _launcher_config
    if not os.path.exists(CONFIG_PATH):
        _launcher_config = DEFAULT_CONFIG.copy()
        return _launcher_config
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        merged = DEFAULT_CONFIG.copy()
        merged.update(data)
        _launcher_config = merged
    except Exception:
        _launcher_config = DEFAULT_CONFIG.copy()
    return _launcher_config


def _save_launcher_config(data):
    payload = DEFAULT_CONFIG.copy()
    payload.update(data)
    with open(CONFIG_PATH, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2, sort_keys=True)


def _default_config_value(key):
    return _load_launcher_config().get(key, DEFAULT_CONFIG[key])


def _build_inner_command(options):
    port = (options.get("port") or "8080").strip() or "8080"
    exports = (
        "export CUDA_HOME=/usr/local/cuda-13.0; "
        'export PATH="$CUDA_HOME/bin:$PATH"; '
        'export LD_LIBRARY_PATH="$CUDA_HOME/lib64:$LD_LIBRARY_PATH"; '
    )

    if options["backend"] == "2.1":
        repo = options["hunyuan21_path"].strip() or "~/Hunyuan3D-2.1"
        cmd = [
            "python",
            "-u",
            "api_server.py",
            "--host",
            "0.0.0.0",
            "--port",
            port,
            "--model_path",
            "tencent/Hunyuan3D-2.1",
            "--subfolder",
            "hunyuan3d-dit-v2-1",
        ]
        if options.get("enable_text"):
            cmd.append("--enable_t23d")
        if options.get("low_vram"):
            cmd.append("--low_vram_mode")
        return f"{exports}cd {repo}; source .venv/bin/activate; " + " ".join(cmd)

    repo = options["hunyuan2_path"].strip() or "~/Hunyuan3D-2"
    subfolder = "hunyuan3d-dit-v2-mv-turbo" if options.get("turbo") else "hunyuan3d-dit-v2-mv"
    cmd = [
        "python",
        "-u",
        "api_server_mv.py",
        "--host",
        "0.0.0.0",
        "--port",
        port,
        "--model_path",
        "tencent/Hunyuan3D-2mv",
        "--subfolder",
        subfolder,
        "--tex_model_path",
        "tencent/Hunyuan3D-2",
    ]
    if options.get("texture"):
        cmd.append("--enable_tex")
    if options.get("enable_text"):
        cmd.append("--enable_t23d")
    if options.get("flashvdm"):
        cmd.append("--enable_flashvdm")
    return f"{exports}cd {repo}; source .venv/bin/activate; " + " ".join(cmd)


def _apply_server_control_state(state, message=None):
    for scene in bpy.data.scenes:
        props = getattr(scene, "nymphs3d2_props", None)
        if props is None:
            continue
        props.server_control_state = state
        if message is not None:
            props.server_control_message = message
    _tag_ui_redraw()
    return None


def _queue_server_control_state(state, message=None):
    bpy.app.timers.register(lambda: _apply_server_control_state(state, message), first_interval=0.0)


def _set_managed_process(proc):
    global _server_process
    with _server_process_lock:
        _server_process = proc


def _get_managed_process():
    with _server_process_lock:
        return _server_process


def _clear_managed_process(proc=None):
    global _server_process
    with _server_process_lock:
        if proc is None or _server_process is proc:
            _server_process = None


def _managed_process_running():
    proc = _get_managed_process()
    return proc is not None and proc.poll() is None


def _server_process_monitor(proc):
    code = proc.wait()
    _clear_managed_process(proc)
    message = "Server stopped"
    if code not in (0, -15):
        message = f"Server exited with code {code}"
    _queue_server_control_state("Stopped", message)
    _queue_server_stats_apply(
        {
            "status": "Unavailable",
            "model_path": "Unknown",
            "subfolder": "Unknown",
            "enable_flashvdm": "Unknown",
            "enable_tex": "Unknown",
            "enable_t23d": "Unknown",
        }
    )


def _server_output_reader(proc):
    if proc.stdout is None:
        return
    try:
        for raw_line in proc.stdout:
            if _get_managed_process() is not proc:
                break
            label, detail, progress = _filtered_output_message(raw_line)
            if label:
                message = label
                if progress:
                    message = f"{message} {progress}"
                elif detail:
                    message = f"{message} {detail}"
                _queue_server_control_state("Launching", message)
                _queue_startup_progress(stage=label, detail=detail, progress=progress)
    except Exception:
        return


def _server_options_from_props(props):
    return {
        "backend": props.server_backend,
        "texture": props.server_start_texture,
        "turbo": props.server_turbo,
        "enable_text": props.server_enable_text,
        "flashvdm": props.server_flashvdm,
        "low_vram": props.server_low_vram,
        "port": props.server_port,
        "hunyuan2_path": props.server_hunyuan2_path,
        "hunyuan21_path": props.server_hunyuan21_path,
    }


def _backend_repo_path(props):
    backend = _infer_backend(props.server_model_path, props.server_subfolder)
    if backend == "Unknown":
        backend = props.server_backend
    if backend == "2.1":
        return props.server_hunyuan21_path.strip() or "~/Hunyuan3D-2.1"
    return props.server_hunyuan2_path.strip() or "~/Hunyuan3D-2"


def _server_port_update(self, context):
    port = (self.server_port or "").strip() or "8080"
    if self.api_url.startswith("http://localhost:") or self.api_url.startswith("http://127.0.0.1:"):
        self.api_url = f"http://localhost:{port}"


def _api_url_is_local(api_url):
    try:
        host = (urlparse((api_url or "").strip()).hostname or "").lower()
    except Exception:
        return False
    return host in {"localhost", "127.0.0.1"}


def _ensure_network_access(api_url):
    if _api_url_is_local(api_url):
        return
    if getattr(bpy.app, "online_access", True):
        return
    raise RuntimeError(
        "Blender online access is disabled. Enable online access in Blender Preferences or use a local API URL."
    )


def _stop_all_local_hunyuan_servers(port=None):
    port = (port or "").strip()
    port_kill = ""
    if port:
        port_kill = (
            f'(command -v fuser >/dev/null 2>&1 && fuser -k {port}/tcp >/dev/null 2>&1) || '
            f'(command -v ss >/dev/null 2>&1 && pids=$(ss -lptn "sport = :{port}" 2>/dev/null | '
            "sed -n 's/.*pid=\\([0-9]\\+\\).*/\\1/p' | sort -u); "
            'for pid in $pids; do kill "$pid" >/dev/null 2>&1 || true; done) || true; '
        )
    inner = (
        port_kill +
        'pkill -f "python -u api_server.py" 2>/dev/null || true; '
        'pkill -f "python -u api_server_mv.py" 2>/dev/null || true; '
        'pkill -f "python api_server.py" 2>/dev/null || true; '
        'pkill -f "python api_server_mv.py" 2>/dev/null || true'
    )
    try:
        subprocess.run(
            ["wsl", "bash", "-lc", inner],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        return True
    except Exception:
        return False


def _sync_server_panel_timer():
    state = "Running" if _managed_process_running() else "Stopped"
    now = time.time()
    for scene in bpy.data.scenes:
        props = getattr(scene, "nymphs3d2_props", None)
        if props is None:
            continue
        server_available = props.server_status not in {"Unavailable", "Not checked", ""}
        launch_grace_active = (
            props.server_launch_requested_at > 0
            and (now - props.server_launch_requested_at) < SERVER_LAUNCH_GRACE_SECONDS
        )
        if state == "Running" and props.server_control_state not in {"Launching", "Stopping"}:
            props.server_control_state = "Running"
        elif server_available and props.server_control_state not in {"Launching", "Stopping"}:
            props.server_control_state = "Running"
            props.server_launch_requested_at = 0.0
        elif launch_grace_active and not server_available and props.server_control_state != "Stopping":
            props.server_control_state = "Launching"
        elif state == "Stopped" and not server_available and props.server_control_state == "Running":
            props.server_control_state = "Stopped"
    return SERVER_SYNC_SECONDS


def _apply_server_stats(stats):
    global _server_cache, _server_refresh_inflight
    _server_cache = stats
    for scene in bpy.data.scenes:
        props = getattr(scene, "nymphs3d2_props", None)
        if props is None:
            continue
        props.server_status = stats["status"]
        props.server_model_path = stats["model_path"]
        props.server_subfolder = stats["subfolder"]
        props.server_enable_flashvdm = stats["enable_flashvdm"]
        props.server_enable_tex = stats["enable_tex"]
        props.server_enable_t23d = stats["enable_t23d"]
        if stats["status"] != "Unavailable" and props.server_control_state == "Launching":
            props.server_control_state = "Running"
            props.server_control_message = "Server ready"
            props.server_launch_requested_at = 0.0
            props.startup_stage = ""
            props.startup_detail = ""
            props.startup_progress = ""
    _server_refresh_inflight = False
    _tag_ui_redraw()
    return None


def _queue_server_stats_apply(stats):
    bpy.app.timers.register(lambda: _apply_server_stats(stats), first_interval=0.0)


def _server_refresh_worker(api_url, force=False):
    try:
        stats = _poll_server_info(api_url, force=force)
    except Exception:
        stats = {
            "status": "Unavailable",
            "model_path": "Unknown",
            "subfolder": "Unknown",
            "enable_flashvdm": "Unknown",
            "enable_tex": "Unknown",
            "enable_t23d": "Unknown",
        }
    _queue_server_stats_apply(stats)


def _request_server_refresh(api_url, force=False):
    global _last_server_refresh_request, _server_refresh_inflight
    api_url = (api_url or "").strip()
    if not api_url:
        return False

    now = time.time()
    if _server_refresh_inflight:
        return False
    if not force and now - _last_server_refresh_request < SERVER_REFRESH_DEBOUNCE_SECONDS:
        return False

    _last_server_refresh_request = now
    _server_refresh_inflight = True
    thread = threading.Thread(target=_server_refresh_worker, args=(api_url, force), daemon=True)
    thread.start()
    return True


def _apply_active_task(stats):
    global _active_task_cache, _active_task_refresh_inflight
    _active_task_cache = stats
    for scene in bpy.data.scenes:
        props = getattr(scene, "nymphs3d2_props", None)
        if props is None:
            continue

        status = (stats.get("status") or "").lower()
        stage = stats.get("stage") or ""
        detail = stats.get("detail") or ""
        progress_text = stats.get("progress_text") or ""
        message = stats.get("message") or ""

        if status == "completed":
            props.active_task_status = "idle"
            props.active_task_stage = ""
            props.active_task_detail = ""
            props.active_task_progress = ""
            props.active_task_message = ""
            if not props.is_processing:
                props.waiting_for_backend_progress = False
                props.saw_real_backend_progress = False
            continue

        if props.is_processing and props.waiting_for_backend_progress:
            real_progress_arrived = (
                status == "processing"
                and not _is_hidden_stage(stage)
                and (
                    bool(stage)
                    or bool(detail)
                    or bool(progress_text)
                )
            )
            if not real_progress_arrived:
                continue
            props.waiting_for_backend_progress = False
            props.saw_real_backend_progress = True

        if status not in {"processing", "queued"} or _is_hidden_stage(stage):
            if not props.is_processing:
                props.active_task_status = "idle"
                props.active_task_stage = ""
                props.active_task_detail = ""
                props.active_task_progress = ""
                props.active_task_message = ""
            continue

        props.active_task_status = status
        props.active_task_stage = stage
        props.active_task_detail = detail
        props.active_task_progress = progress_text
        props.active_task_message = message
    _active_task_refresh_inflight = False
    _tag_ui_redraw()
    return None


def _queue_active_task_apply(stats):
    bpy.app.timers.register(lambda: _apply_active_task(stats), first_interval=0.0)


def _poll_active_task(api_url):
    try:
        response = _http_request("GET", f"{api_url.rstrip('/')}/active_task", timeout=1.5)
        if response.status_code == 404:
            return {
                "status": "unsupported",
                "stage": "",
                "detail": "",
                "progress_text": "",
                "message": "",
            }
        response.raise_for_status()
        data = response.json()
        stage = data.get("stage") or ""
        detail = data.get("detail") or data.get("message") or ""
        message = data.get("message") or ""
        return {
            "status": data.get("status", "idle"),
            "stage": _stage_label(stage),
            "detail": detail,
            "progress_text": _format_progress_text(
                current=data.get("progress_current"),
                total=data.get("progress_total"),
                percent=data.get("progress_percent"),
            ),
            "message": message,
        }
    except Exception:
        return {
            "status": "unavailable",
            "stage": "",
            "detail": "",
            "progress_text": "",
            "message": "",
        }


def _active_task_worker(api_url):
    stats = _poll_active_task(api_url)
    _queue_active_task_apply(stats)


def _request_active_task_refresh(api_url):
    global _active_task_refresh_inflight
    api_url = (api_url or "").strip()
    if not api_url or _active_task_refresh_inflight:
        return False
    _active_task_refresh_inflight = True
    thread = threading.Thread(target=_active_task_worker, args=(api_url,), daemon=True)
    thread.start()
    return True


def _startup_server_refresh_timer():
    for scene in bpy.data.scenes:
        props = getattr(scene, "nymphs3d2_props", None)
        if props is None:
            continue
        _request_server_refresh(props.api_url, force=True)
        _request_active_task_refresh(props.api_url)
        break
    return None


def _on_api_url_changed(self, context):
    _request_server_refresh(self.api_url, force=True)
    _request_active_task_refresh(self.api_url)


def _load_presets():
    if not os.path.exists(PRESET_PATH):
        return {}
    try:
        with open(PRESET_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_presets(data):
    with open(PRESET_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, sort_keys=True)


def _preset_items(self, context):
    items = [("", "Select Saved Settings", "Load a saved setting set")]
    for name in sorted(_load_presets()):
        items.append((name, name, f"Load saved settings: {name}"))
    return items


def _poll_gpu_stats(force=False):
    global _last_gpu_poll, _gpu_cache
    now = time.time()
    if not force and now - _last_gpu_poll < GPU_REFRESH_SECONDS:
        return _gpu_cache

    try:
        result = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=name,memory.total,memory.used,utilization.gpu",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=2,
            check=True,
        )
        line = result.stdout.strip().splitlines()[0]
        name, mem_total, mem_used, util = [part.strip() for part in line.split(",")]
        _gpu_cache = {
            "name": name,
            "memory": f"{mem_used} / {mem_total} MB",
            "utilization": f"{util}%",
            "status": "Connected",
        }
    except Exception:
        _gpu_cache = {
            "name": "Unavailable",
            "memory": "Unavailable",
            "utilization": "Unavailable",
            "status": "nvidia-smi not available",
        }
    _last_gpu_poll = now
    return _gpu_cache


def _gpu_status_timer():
    stats = _poll_gpu_stats(force=True)
    for scene in bpy.data.scenes:
        props = getattr(scene, "nymphs3d2_props", None)
        if props is None:
            continue
        props.gpu_name = stats["name"]
        props.gpu_memory = stats["memory"]
        props.gpu_utilization = stats["utilization"]
        props.gpu_status_message = stats["status"]
    return GPU_REFRESH_SECONDS


def _active_task_timer():
    next_interval = ACTIVE_TASK_IDLE_SECONDS
    for scene in bpy.data.scenes:
        props = getattr(scene, "nymphs3d2_props", None)
        if props is None:
            continue
        _request_active_task_refresh(props.api_url)
        status = (props.active_task_status or "").lower()
        if props.is_processing:
            next_interval = ACTIVE_TASK_DIRECT_JOB_SECONDS
        elif status in {"processing", "queued"}:
            next_interval = ACTIVE_TASK_BUSY_SECONDS
        elif status in {"unsupported", "unavailable"}:
            next_interval = ACTIVE_TASK_UNAVAILABLE_SECONDS
        break
    return next_interval


def _server_info_timer():
    next_interval = SERVER_INFO_READY_SECONDS
    for scene in bpy.data.scenes:
        props = getattr(scene, "nymphs3d2_props", None)
        if props is None:
            continue
        _request_server_refresh(props.api_url)
        state = (props.server_control_state or "").lower()
        status = (props.server_status or "").lower()
        if state in {"launching", "stopping"}:
            next_interval = SERVER_INFO_LAUNCHING_SECONDS
        elif status in {"unavailable", "not checked"}:
            next_interval = SERVER_INFO_UNAVAILABLE_SECONDS
        break
    return next_interval


def _poll_server_info(api_url, force=False):
    global _server_cache
    try:
        response = _http_request("GET", f"{api_url.rstrip('/')}/server_info", timeout=2)
        response.raise_for_status()
        data = response.json()
        _server_cache = {
            "status": data.get("status", "ok"),
            "model_path": data.get("model_path", "Unknown"),
            "subfolder": data.get("subfolder", "Unknown"),
            "enable_flashvdm": str(data.get("enable_flashvdm", "Unknown")),
            "enable_tex": str(data.get("enable_tex", "Unknown")),
            "enable_t23d": str(data.get("enable_t23d", "Unknown")),
        }
    except Exception:
        _server_cache = {
            "status": "Unavailable",
            "model_path": "Unknown",
            "subfolder": "Unknown",
            "enable_flashvdm": "Unknown",
            "enable_tex": "Unknown",
            "enable_t23d": "Unknown",
        }
    return _server_cache


class Hunyuan3DProperties(bpy.types.PropertyGroup):
    prompt: StringProperty(
        name="Text Prompt",
        description="Describe what you want to generate",
        default=""
    )
    api_url: StringProperty(
        name="API URL",
        description="URL of the Text-to-3D API service",
        default="http://localhost:8080",
        update=_on_api_url_changed,
    )
    server_backend: EnumProperty(
        name="Backend",
        items=(
            ("2mv", "2mv", "Hunyuan 2 multiview backend"),
            ("2.1", "2.1", "Hunyuan 2.1 backend"),
        ),
        default="2mv",
    )
    server_start_texture: BoolProperty(
        name="Texture At Startup",
        description="Start the server with texture support enabled",
        default=True,
    )
    server_enable_text: BoolProperty(
        name="Text Prompt Support",
        description="Enable text-prompt bridge support at server startup",
        default=False,
    )
    server_turbo: BoolProperty(
        name="Turbo",
        description="Use the faster 2mv turbo model",
        default=True,
    )
    server_flashvdm: BoolProperty(
        name="FlashVDM",
        description="Enable FlashVDM for the 2mv backend",
        default=True,
    )
    server_low_vram: BoolProperty(
        name="Low VRAM",
        description="Enable low VRAM mode for the 2.1 backend",
        default=True,
    )
    server_open_terminal: BoolProperty(
        name="Open Terminal Window",
        description="Launch the local server in a visible console window when supported",
        default=False,
    )
    server_port: StringProperty(
        name="Port",
        description="Local API port",
        default=_default_config_value("port"),
        update=_server_port_update,
    )
    server_hunyuan2_path: StringProperty(
        name="2mv Path",
        description="WSL path to the Hunyuan3D-2 repo",
        default=_default_config_value("hunyuan2_path"),
    )
    server_hunyuan21_path: StringProperty(
        name="2.1 Path",
        description="WSL path to the Hunyuan3D-2.1 repo",
        default=_default_config_value("hunyuan21_path"),
    )
    is_processing: BoolProperty(
        name="Processing",
        default=False
    )
    job_id: StringProperty(
        name="Job ID",
        default=""
    )
    status_message: StringProperty(
        name="Status Message",
        default=""
    )
    # Single-image input
    image_path: StringProperty(
        name="Image",
        description="Select an image to upload",
        subtype='FILE_PATH'
    )
    # Multi-view inputs
    use_multiview: BoolProperty(
        name="Use MultiView",
        description="Use Front/Back/Left/Right image inputs",
        default=False
    )
    mv_image_front: StringProperty(
        name="Front",
        description="Front view image",
        subtype='FILE_PATH'
    )
    mv_image_back: StringProperty(
        name="Back",
        description="Back view image",
        subtype='FILE_PATH'
    )
    mv_image_left: StringProperty(
        name="Left",
        description="Left view image",
        subtype='FILE_PATH'
    )
    mv_image_right: StringProperty(
        name="Right",
        description="Right view image",
        subtype='FILE_PATH'
    )
    # Generation settings
    auto_remove_background: BoolProperty(
        name="Auto Remove Background",
        description="Automatically isolate the subject from the background before generation",
        default=False,
    )
    octree_resolution: IntProperty(
        name="Mesh Detail",
        description="Higher values keep more shape detail but take longer and use more GPU memory",
        default=256,
        min=128,
        max=512,
    )
    num_inference_steps: IntProperty(
        name="Detail Passes",
        description="Higher values spend longer refining the result",
        default=20,
        min=20,
        max=100
    )
    guidance_scale: FloatProperty(
        name="Reference Strength",
        description="How strongly the result should follow the input images",
        default=5.5,
        min=1.0,
        max=10.0
    )
    texture: BoolProperty(
        name="Generate Texture",
        description="Whether to generate texture for the 3D model",
        default=False
    )
    preset_name: StringProperty(
        name="Preset Name",
        description="Name to use when saving the current settings",
        default="",
    )
    selected_preset: EnumProperty(
        name="Saved Settings",
        description="Load a previously saved setting set",
        items=_preset_items,
    )
    show_saved_setups: BoolProperty(name="Show Saved Setups", default=False)
    show_server_advanced: BoolProperty(name="Show Server Advanced", default=False)
    show_server_settings: BoolProperty(name="Show Server Settings", default=False)
    show_server_controls: BoolProperty(name="Show Server Controls", default=False)
    show_server_info: BoolProperty(name="Show Server Info", default=False)
    show_server_gpu: BoolProperty(name="Show Server GPU", default=False)
    gpu_name: StringProperty(name="GPU Name", default="Unknown")
    gpu_memory: StringProperty(name="GPU Memory", default="Unavailable")
    gpu_utilization: StringProperty(name="GPU Utilization", default="Unavailable")
    gpu_status_message: StringProperty(name="GPU Status", default="Not checked")
    server_control_state: StringProperty(name="Server Control State", default="Stopped")
    server_control_message: StringProperty(name="Server Control Message", default="")
    server_launch_requested_at: FloatProperty(name="Server Launch Requested At", default=0.0)
    server_status: StringProperty(name="Server Status", default="Not checked")
    server_model_path: StringProperty(name="Server Model", default="Unknown")
    server_subfolder: StringProperty(name="Server Subfolder", default="Unknown")
    server_enable_flashvdm: StringProperty(name="Server FlashVDM", default="Unknown")
    server_enable_tex: StringProperty(name="Server Texture", default="Unknown")
    server_enable_t23d: StringProperty(name="Server Text2Img", default="Unknown")
    startup_stage: StringProperty(name="Startup Stage", default="")
    startup_detail: StringProperty(name="Startup Detail", default="")
    startup_progress: StringProperty(name="Startup Progress", default="")
    active_task_status: StringProperty(name="Active Task Status", default="idle")
    active_task_stage: StringProperty(name="Active Task Stage", default="")
    active_task_detail: StringProperty(name="Active Task Detail", default="")
    active_task_progress: StringProperty(name="Active Task Progress", default="")
    active_task_message: StringProperty(name="Active Task Message", default="")
    generation_started_at: FloatProperty(name="Generation Started At", default=0.0)
    waiting_for_backend_progress: BoolProperty(name="Waiting For Backend Progress", default=False)
    saw_real_backend_progress: BoolProperty(name="Saw Real Backend Progress", default=False)
    generation_request_token: IntProperty(name="Generation Request Token", default=0)
    generation_request_finished_locally: BoolProperty(name="Generation Request Finished Locally", default=False)


class Hunyuan3DSavePresetOperator(bpy.types.Operator):
    bl_idname = "nymphs3d2.save_preset"
    bl_label = "Save Settings"
    bl_description = "Save the current Hunyuan3D settings"

    def execute(self, context):
        props = context.scene.nymphs3d2_props
        name = props.preset_name.strip()
        if not name:
            self.report({'WARNING'}, "Enter a preset name first.")
            return {'CANCELLED'}

        data = _load_presets()
        data[name] = {
            "use_multiview": props.use_multiview,
            "auto_remove_background": props.auto_remove_background,
            "octree_resolution": props.octree_resolution,
            "num_inference_steps": props.num_inference_steps,
            "guidance_scale": props.guidance_scale,
            "texture": props.texture,
            "api_url": props.api_url,
        }
        _save_presets(data)
        props.selected_preset = name
        self.report({'INFO'}, f"Saved settings: {name}")
        return {'FINISHED'}


class Hunyuan3DLoadPresetOperator(bpy.types.Operator):
    bl_idname = "nymphs3d2.load_preset"
    bl_label = "Load Settings"
    bl_description = "Load the selected Hunyuan3D settings"

    def execute(self, context):
        props = context.scene.nymphs3d2_props
        name = props.selected_preset
        data = _load_presets()
        if not name or name not in data:
            self.report({'WARNING'}, "Select a saved setting set first.")
            return {'CANCELLED'}

        preset = data[name]
        props.use_multiview = preset.get("use_multiview", props.use_multiview)
        props.auto_remove_background = preset.get("auto_remove_background", props.auto_remove_background)
        props.octree_resolution = preset.get("octree_resolution", props.octree_resolution)
        props.num_inference_steps = preset.get("num_inference_steps", props.num_inference_steps)
        props.guidance_scale = preset.get("guidance_scale", props.guidance_scale)
        props.texture = preset.get("texture", props.texture)
        props.api_url = preset.get("api_url", props.api_url)
        self.report({'INFO'}, f"Loaded settings: {name}")
        return {'FINISHED'}


class Hunyuan3DDeletePresetOperator(bpy.types.Operator):
    bl_idname = "nymphs3d2.delete_preset"
    bl_label = "Delete Settings"
    bl_description = "Delete the selected Hunyuan3D settings"

    def execute(self, context):
        props = context.scene.nymphs3d2_props
        name = props.selected_preset
        data = _load_presets()
        if not name or name not in data:
            self.report({'WARNING'}, "Select a saved setting set first.")
            return {'CANCELLED'}

        del data[name]
        _save_presets(data)
        props.selected_preset = ""
        self.report({'INFO'}, f"Deleted settings: {name}")
        return {'FINISHED'}


class Hunyuan3DRefreshGPUOperator(bpy.types.Operator):
    bl_idname = "nymphs3d2.refresh_gpu"
    bl_label = "Refresh GPU"
    bl_description = "Refresh GPU usage information"

    def execute(self, context):
        stats = _poll_gpu_stats(force=True)
        props = context.scene.nymphs3d2_props
        props.gpu_name = stats["name"]
        props.gpu_memory = stats["memory"]
        props.gpu_utilization = stats["utilization"]
        props.gpu_status_message = stats["status"]
        return {'FINISHED'}


class Hunyuan3DRefreshServerOperator(bpy.types.Operator):
    bl_idname = "nymphs3d2.refresh_server"
    bl_label = "Refresh Server"
    bl_description = "Refresh active server information"

    def execute(self, context):
        props = context.scene.nymphs3d2_props
        props.server_status = "Refreshing..."
        _request_server_refresh(props.api_url, force=True)
        _request_active_task_refresh(props.api_url)
        return {'FINISHED'}


class Hunyuan3DStartServerOperator(bpy.types.Operator):
    bl_idname = "nymphs3d2.start_server"
    bl_label = "Start Server"
    bl_description = "Start the local WSL Hunyuan server from Blender"

    def execute(self, context):
        props = context.scene.nymphs3d2_props
        if _managed_process_running():
            self.report({'INFO'}, "A managed server is already running.")
            return {'CANCELLED'}
        if props.server_status not in {"Unavailable", "Not checked"}:
            self.report({'WARNING'}, "A server already appears to be running on this API URL.")
            return {'CANCELLED'}

        options = _server_options_from_props(props)
        if _api_url_is_local(props.api_url):
            _stop_all_local_hunyuan_servers(props.server_port)
        inner = _build_inner_command(options)
        command = ["wsl", "bash", "-lc", inner]
        try:
            creationflags = 0
            startupinfo = None
            if os.name == "nt":
                if props.server_open_terminal:
                    creationflags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
                else:
                    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
                    startupinfo = subprocess.STARTUPINFO()
                    startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                    startupinfo.wShowWindow = 0
            popen_kwargs = dict(
                text=True,
                bufsize=1,
                creationflags=creationflags,
                startupinfo=startupinfo,
            )
            if props.server_open_terminal and os.name == "nt":
                popen_kwargs["stdout"] = None
                popen_kwargs["stderr"] = None
            else:
                popen_kwargs["stdout"] = subprocess.PIPE
                popen_kwargs["stderr"] = subprocess.STDOUT
            proc = subprocess.Popen(
                command,
                **popen_kwargs,
            )
        except Exception as exc:
            props.server_control_state = "Stopped"
            props.server_control_message = str(exc)
            self.report({'ERROR'}, f"Launch failed: {exc}")
            return {'CANCELLED'}

        _set_managed_process(proc)
        _save_launcher_config(
            {
                "hunyuan2_path": props.server_hunyuan2_path,
                "hunyuan21_path": props.server_hunyuan21_path,
                "port": props.server_port,
            }
        )
        props.server_control_state = "Launching"
        props.server_launch_requested_at = time.time()
        props.active_task_status = "idle"
        props.active_task_stage = ""
        props.active_task_detail = ""
        props.active_task_progress = ""
        props.active_task_message = ""
        props.waiting_for_backend_progress = False
        props.saw_real_backend_progress = False
        props.generation_request_finished_locally = False
        props.startup_stage = "Launch Requested"
        props.startup_detail = "Waiting for server startup..."
        props.startup_progress = ""
        if props.server_open_terminal and os.name == "nt":
            props.server_control_message = "Starting local WSL server in a terminal window..."
        else:
            props.server_control_message = "Starting local WSL server..."
        _request_server_refresh(props.api_url, force=True)
        _request_active_task_refresh(props.api_url)
        if proc.stdout is not None:
            threading.Thread(target=_server_output_reader, args=(proc,), daemon=True).start()
        threading.Thread(target=_server_process_monitor, args=(proc,), daemon=True).start()
        return {'FINISHED'}


class Hunyuan3DStopServerOperator(bpy.types.Operator):
    bl_idname = "nymphs3d2.stop_server"
    bl_label = "Stop Server"
    bl_description = "Stop the managed local WSL Hunyuan server"

    def execute(self, context):
        props = context.scene.nymphs3d2_props
        port = (props.server_port or "8080").strip() or "8080"
        proc = _get_managed_process()
        if proc is None or proc.poll() is not None:
            if props.server_status not in {"Unavailable", "Not checked"} and _api_url_is_local(props.api_url):
                if _stop_all_local_hunyuan_servers(port):
                    props.server_control_state = "Stopping"
                    props.server_control_message = "Stopping local Hunyuan servers..."
                    _request_server_refresh(props.api_url, force=True)
                    _request_active_task_refresh(props.api_url)
                    return {'FINISHED'}
            props.server_control_state = "Stopped"
            props.server_control_message = "No managed server is running."
            return {'CANCELLED'}
        try:
            proc.terminate()
            props.server_control_state = "Stopping"
            props.server_control_message = "Stopping server..."
            if _api_url_is_local(props.api_url):
                _stop_all_local_hunyuan_servers(port)
        except Exception as exc:
            self.report({'ERROR'}, f"Stop failed: {exc}")
            return {'CANCELLED'}
        return {'FINISHED'}


class Hunyuan3DOperator(bpy.types.Operator):
    bl_idname = "nymphs3d2.generate_3d"
    bl_label = "Generate 3D Model"
    bl_description = "Generate a 3D model from text description, an image or a selected mesh"

    job_id = ''
    prompt = ""
    api_url = ""
    image_path = ""
    use_multiview = False
    mv_image_front = ""
    mv_image_back = ""
    mv_image_left = ""
    mv_image_right = ""
    octree_resolution = 256
    num_inference_steps = 20
    guidance_scale = 5.5
    auto_remove_background = False
    texture = False
    selected_mesh_base64 = ""
    selected_mesh = None

    thread = None
    task_finished = False
    redraw_timer = None
    request_token = 0

    def _resolve_path(self, path):
        if not path:
            return ""
        if path.startswith('//'):
            blend_file_dir = os.path.dirname(bpy.data.filepath)
            path = os.path.join(blend_file_dir, path[2:])
        return path

    def _encode_image_file(self, path):
        if not path:
            return None
        path = self._resolve_path(path)
        if not os.path.exists(path):
            raise Exception(f'Image path does not exist {path}')
        with open(path, "rb") as file:
            return base64.b64encode(file.read()).decode()

    def _build_mv_payload(self):
        payload = {}
        front = self._encode_image_file(self.mv_image_front) if self.mv_image_front else None
        back = self._encode_image_file(self.mv_image_back) if self.mv_image_back else None
        left = self._encode_image_file(self.mv_image_left) if self.mv_image_left else None
        right = self._encode_image_file(self.mv_image_right) if self.mv_image_right else None
        if front:
            payload["mv_image_front"] = front
        if back:
            payload["mv_image_back"] = back
        if left:
            payload["mv_image_left"] = left
        if right:
            payload["mv_image_right"] = right
        return payload

    def modal(self, context, event):
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            return {'CANCELLED'}

        if event.type == 'TIMER':
            _tag_ui_redraw()

        if self.task_finished:
            self.task_finished = False
            props = context.scene.nymphs3d2_props
            if props.generation_request_token == self.request_token:
                props.generation_request_finished_locally = True
                props.is_processing = False
                props.waiting_for_backend_progress = False
                props.saw_real_backend_progress = False
                props.active_task_status = "idle"
                props.active_task_stage = ""
                props.active_task_detail = ""
                props.active_task_progress = ""
                props.active_task_message = ""
            if self.redraw_timer is not None:
                context.window_manager.event_timer_remove(self.redraw_timer)
                self.redraw_timer = None
            _tag_ui_redraw()
            return {'FINISHED'}

        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        # 启动线程
        props = context.scene.nymphs3d2_props
        self.prompt = props.prompt
        self.api_url = props.api_url
        self.image_path = props.image_path
        self.use_multiview = props.use_multiview
        self.mv_image_front = props.mv_image_front
        self.mv_image_back = props.mv_image_back
        self.mv_image_left = props.mv_image_left
        self.mv_image_right = props.mv_image_right
        self.octree_resolution = props.octree_resolution
        self.num_inference_steps = props.num_inference_steps
        self.guidance_scale = props.guidance_scale
        self.auto_remove_background = props.auto_remove_background
        self.texture = props.texture

        has_mv = any([self.mv_image_front, self.mv_image_back, self.mv_image_left, self.mv_image_right])
        if self.use_multiview:
            if not has_mv:
                self.report({'WARNING'}, "Please select at least one multiview image.")
                return {'FINISHED'}
        else:
            if self.prompt == "" and self.image_path == "":
                self.report({'WARNING'}, "Please enter some text or select an image first.")
                return {'FINISHED'}

        # 保存选中的 mesh 对象引用
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                self.selected_mesh = obj
                break

        if self.selected_mesh:
            temp_glb_file = tempfile.NamedTemporaryFile(delete=False, suffix=".glb")
            temp_glb_file.close()
            bpy.ops.export_scene.gltf(filepath=temp_glb_file.name, use_selection=True)
            with open(temp_glb_file.name, "rb") as file:
                mesh_data = file.read()
            mesh_b64_str = base64.b64encode(mesh_data).decode()
            os.unlink(temp_glb_file.name)
            self.selected_mesh_base64 = mesh_b64_str

        props.is_processing = True
        props.generation_request_token += 1
        self.request_token = props.generation_request_token
        props.generation_started_at = time.time()
        props.waiting_for_backend_progress = True
        props.saw_real_backend_progress = False
        props.generation_request_finished_locally = False
        props.active_task_status = "queued"
        props.active_task_stage = "Request Sent"
        props.active_task_detail = "Waiting for backend progress..."
        props.active_task_progress = ""
        props.active_task_message = ""
        _request_active_task_refresh(props.api_url)

        self.image_path = self._resolve_path(self.image_path)
        self.mv_image_front = self._resolve_path(self.mv_image_front)
        self.mv_image_back = self._resolve_path(self.mv_image_back)
        self.mv_image_left = self._resolve_path(self.mv_image_left)
        self.mv_image_right = self._resolve_path(self.mv_image_right)

        if self.selected_mesh and self.texture:
            props.status_message = "Texturing Selected Mesh...\n" \
                                   "This may take several minutes depending \n on your GPU power."
        else:
            mesh_type = 'Textured Mesh' if self.texture else 'White Mesh'
            if self.use_multiview:
                prompt_type = 'MultiView Images'
            else:
                prompt_type = 'Text Prompt' if self.prompt else 'Image'
            props.status_message = f"Generating {mesh_type} with {prompt_type}...\n" \
                                   "This may take several minutes depending \n on your GPU power."

        self.thread = threading.Thread(target=self.generate_model, args=[context])
        self.thread.start()

        wm = context.window_manager
        self.redraw_timer = wm.event_timer_add(0.25, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def generate_model(self, context):
        self.report({'INFO'}, f"Generation Start")
        base_url = self.api_url.rstrip('/')

        try:
            base_payload = {
                "octree_resolution": self.octree_resolution,
                "num_inference_steps": self.num_inference_steps,
                "guidance_scale": self.guidance_scale,
                "auto_remove_background": self.auto_remove_background,
                "texture": self.texture
            }

            if self.use_multiview:
                mv_payload = self._build_mv_payload()
                if not mv_payload:
                    raise Exception("No multiview images found.")
            else:
                mv_payload = {}

            if self.selected_mesh_base64 and self.texture:
                payload = dict(base_payload)
                payload["mesh"] = self.selected_mesh_base64
                if self.use_multiview and mv_payload:
                    self.report({'INFO'}, "Post Texturing with MultiView Images")
                    payload.update(mv_payload)
                elif self.image_path:
                    self.report({'INFO'}, "Post Texturing with Image")
                    payload["image"] = self._encode_image_file(self.image_path)
                else:
                    self.report({'INFO'}, "Post Texturing with Text")
                    payload["text"] = self.prompt
                response = _http_request("POST", f"{base_url}/generate", json_payload=payload)
            else:
                payload = dict(base_payload)
                if self.use_multiview and mv_payload:
                    self.report({'INFO'}, "Post Start MultiView to 3D")
                    payload.update(mv_payload)
                elif self.image_path:
                    self.report({'INFO'}, "Post Start Image to 3D")
                    payload["image"] = self._encode_image_file(self.image_path)
                else:
                    self.report({'INFO'}, "Post Start Text to 3D")
                    payload["text"] = self.prompt
                response = _http_request("POST", f"{base_url}/generate", json_payload=payload)
            self.report({'INFO'}, f"Post Done")
            props = context.scene.nymphs3d2_props

            if response.status_code != 200:
                self.report({'ERROR'}, f"Generation failed: {response.text}")
                return

            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".glb")
            temp_file.write(response.content)
            temp_file.close()

            # Import the GLB file in the main thread
            def import_handler():
                bpy.ops.import_scene.gltf(filepath=temp_file.name)
                os.unlink(temp_file.name)

                # 获取新导入的 mesh
                new_obj = bpy.context.selected_objects[0] if bpy.context.selected_objects else None
                if new_obj and self.selected_mesh and self.texture:
                    # 应用选中 mesh 的位置、旋转和缩放
                    new_obj.location = self.selected_mesh.location
                    new_obj.rotation_euler = self.selected_mesh.rotation_euler
                    new_obj.scale = self.selected_mesh.scale

                    # 隐藏原来的 mesh
                    self.selected_mesh.hide_set(True)
                    self.selected_mesh.hide_render = True

                return None

            bpy.app.timers.register(import_handler)

        except Exception as e:
            self.report({'ERROR'}, f"Error: {str(e)}")

        finally:
            self.task_finished = True
            self.selected_mesh_base64 = ""


class HUNYUAN3D2_PT_server(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Nymphs3D'
    bl_label = 'Server'

    def draw(self, context):
        layout = self.layout
        props = context.scene.nymphs3d2_props
        progress_stage, progress_detail, progress_value = _server_panel_job_lines(props)
        top = layout.box()
        top.label(text=f"Status: {_server_status_line(props)}"[:140])
        top.label(text=f"Current Job: {(progress_stage or 'Idle')}"[:140])
        stage_norm = _normalized_panel_text(progress_stage)
        detail_norm = _normalized_panel_text(progress_detail)
        combined_detail = progress_detail or progress_value
        combined_detail_norm = _normalized_panel_text(combined_detail)
        if combined_detail and combined_detail_norm and combined_detail_norm != stage_norm:
            top.label(text=f"Detail: {combined_detail}"[:140])
        elif props.server_control_state == "Launching" and props.startup_progress:
            top.label(text=f"Detail: {props.startup_progress}"[:140])
        elif props.server_control_message and props.server_control_state in {"Launching", "Stopping"}:
            top.label(text=f"Detail: {props.server_control_message}"[:140])

        controls = layout.box()
        controls.prop(
            props,
            "show_server_controls",
            text="Controls",
            icon='TRIA_DOWN' if props.show_server_controls else 'TRIA_RIGHT',
            emboss=False,
        )
        if props.show_server_controls:
            controls.prop(props, "api_url")
            controls.prop(props, "server_open_terminal")
            row = controls.row(align=True)
            row.operator("nymphs3d2.start_server", text="Start Server")
            row.operator("nymphs3d2.stop_server", text="Stop Server")
            row = controls.row(align=True)
            row.operator("nymphs3d2.refresh_server", text="Refresh Server")
            row.operator("nymphs3d2.refresh_gpu", text="Refresh GPU")

        settings = layout.box()
        settings.prop(
            props,
            "show_server_settings",
            text="Startup Settings",
            icon='TRIA_DOWN' if props.show_server_settings else 'TRIA_RIGHT',
            emboss=False,
        )
        if props.show_server_settings:
            settings.prop(props, "server_backend", expand=True)
            if props.server_backend == "2mv":
                row = settings.row(align=True)
                row.prop(props, "server_start_texture")
                row.prop(props, "server_enable_text")
                row = settings.row(align=True)
                row.prop(props, "server_turbo")
                row.prop(props, "server_flashvdm")
            else:
                row = settings.row(align=True)
                row.prop(props, "server_start_texture")
                row.prop(props, "server_enable_text")
                settings.prop(props, "server_low_vram")

        info = layout.box()
        info.prop(
            props,
            "show_server_info",
            text="Details",
            icon='TRIA_DOWN' if props.show_server_info else 'TRIA_RIGHT',
            emboss=False,
        )
        if props.show_server_info:
            info.label(text=f"Managed: {'Yes' if _managed_process_running() else 'No'}")
            info.label(text=f"Control State: {props.server_control_state}")
            info.label(text=f"Status: {props.server_status}")
            info.label(text=f"Model: {props.server_model_path}")
            info.label(text=f"Subfolder: {props.server_subfolder}")
            info.label(text=f"FlashVDM: {props.server_enable_flashvdm}")
            info.label(text=f"Texture Enabled: {props.server_enable_tex}")
            info.label(text=f"Text Enabled: {props.server_enable_t23d}")
            info.separator()
            estimate, basis, mode, caveat = _current_vram_estimate(props)
            info.label(text=f"VRAM Estimate: {estimate}"[:140])
            info.label(text=f"VRAM Mode: {mode}"[:140])
            info.label(text=f"{basis}"[:140])
            info.label(text=f"VRAM Note: {caveat}"[:140])

        gpu = layout.box()
        gpu.prop(
            props,
            "show_server_gpu",
            text="GPU",
            icon='TRIA_DOWN' if props.show_server_gpu else 'TRIA_RIGHT',
            emboss=False,
        )
        if props.show_server_gpu:
            gpu.label(text=f"GPU: {props.gpu_name}")
            gpu.label(text=f"VRAM: {props.gpu_memory}")
            gpu.label(text=f"Load: {props.gpu_utilization}")
            gpu.label(text=f"Driver Status: {props.gpu_status_message}")

        advanced = layout.box()
        advanced.prop(
            props,
            "show_server_advanced",
            text="Advanced",
            icon='TRIA_DOWN' if props.show_server_advanced else 'TRIA_RIGHT',
            emboss=False,
        )
        if props.show_server_advanced:
            advanced.prop(props, "server_port")
            advanced.prop(props, "server_hunyuan2_path")
            advanced.prop(props, "server_hunyuan21_path")


class HUNYUAN3D2_PT_generate(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Nymphs3D'
    bl_label = 'Generate'

    def draw(self, context):
        layout = self.layout
        props = context.scene.nymphs3d2_props
        backend = _infer_backend(props.server_model_path, props.server_subfolder)
        supports_multiview = backend in {"2mv", "2.0", "Unknown"}
        supports_texture = props.server_enable_tex in {"True", "Unknown"}
        supports_text = props.server_enable_t23d in {"True", "Unknown"}

        if props.server_status == "Unavailable" and not _managed_process_running():
            warn = layout.box()
            warn.label(text="Server info is unavailable.")
            warn.label(text="Start the local server above.")

        row = layout.row()
        row.enabled = supports_multiview
        row.prop(props, "use_multiview")
        if not supports_multiview:
            layout.label(text="Current server does not expose multiview.")

        text_row = layout.row()
        text_row.enabled = supports_text
        text_row.prop(props, "prompt")
        if not supports_text:
            layout.label(text="This server was not started with text support.")

        if props.use_multiview:
            box = layout.box()
            box.label(text="MultiView Images")
            box.prop(props, "mv_image_front")
            box.prop(props, "mv_image_back")
            box.prop(props, "mv_image_left")
            box.prop(props, "mv_image_right")
        else:
            layout.prop(props, "image_path")

        layout.prop(props, "auto_remove_background")
        layout.prop(props, "octree_resolution")
        layout.prop(props, "num_inference_steps")
        layout.prop(props, "guidance_scale")
        texture_row = layout.row()
        texture_row.enabled = supports_texture
        texture_row.prop(props, "texture")
        if not supports_texture:
            layout.label(text="This server was started without texture support.")

        box = layout.box()
        box.prop(
            props,
            "show_saved_setups",
            text="Presets",
            icon='TRIA_DOWN' if props.show_saved_setups else 'TRIA_RIGHT',
            emboss=False,
        )
        if props.show_saved_setups:
            box.prop(props, "preset_name", text="Save As")
            row = box.row(align=True)
            row.operator("nymphs3d2.save_preset", text="Save Current Setup")
            box.prop(props, "selected_preset", text="Load Setup")
            row = box.row(align=True)
            row.operator("nymphs3d2.load_preset", text="Load Setup")
            row.operator("nymphs3d2.delete_preset", text="Delete Setup")

        row = layout.row()
        row.enabled = not props.is_processing
        row.operator("nymphs3d2.generate_3d")

        if props.is_processing:
            if props.status_message:
                for line in props.status_message.split("\n"):
                    layout.label(text=line)
            else:
                layout.label("Processing...")


classes = (
    Hunyuan3DProperties,
    Hunyuan3DSavePresetOperator,
    Hunyuan3DLoadPresetOperator,
    Hunyuan3DDeletePresetOperator,
    Hunyuan3DRefreshGPUOperator,
    Hunyuan3DRefreshServerOperator,
    Hunyuan3DStartServerOperator,
    Hunyuan3DStopServerOperator,
    Hunyuan3DOperator,
    HUNYUAN3D2_PT_server,
    HUNYUAN3D2_PT_generate,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.nymphs3d2_props = bpy.props.PointerProperty(type=Hunyuan3DProperties)
    if not bpy.app.timers.is_registered(_gpu_status_timer):
        bpy.app.timers.register(_gpu_status_timer, persistent=True)
    if not bpy.app.timers.is_registered(_active_task_timer):
        bpy.app.timers.register(_active_task_timer, persistent=True)
    if not bpy.app.timers.is_registered(_server_info_timer):
        bpy.app.timers.register(_server_info_timer, persistent=True)
    if not bpy.app.timers.is_registered(_sync_server_panel_timer):
        bpy.app.timers.register(_sync_server_panel_timer, persistent=True)
    bpy.app.timers.register(_startup_server_refresh_timer, first_interval=1.5, persistent=True)


def unregister():
    if bpy.app.timers.is_registered(_gpu_status_timer):
        bpy.app.timers.unregister(_gpu_status_timer)
    if bpy.app.timers.is_registered(_active_task_timer):
        bpy.app.timers.unregister(_active_task_timer)
    if bpy.app.timers.is_registered(_server_info_timer):
        bpy.app.timers.unregister(_server_info_timer)
    if bpy.app.timers.is_registered(_sync_server_panel_timer):
        bpy.app.timers.unregister(_sync_server_panel_timer)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.nymphs3d2_props


if __name__ == "__main__":
    register()
