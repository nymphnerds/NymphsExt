"""Implementation variants for the Nymphs3D2 addon."""
