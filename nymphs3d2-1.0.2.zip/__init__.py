"""Live Blender addon entrypoint for Nymphs3D2."""

try:
    from .experiments.Nymphs3D2v2 import *  # noqa: F401,F403
except ImportError:
    from experiments.Nymphs3D2v2 import *  # type: ignore # noqa: F401,F403
